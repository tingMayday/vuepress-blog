---
home: true
defaultHome: true
isShowTitleInHome: true
bgImage: '/bg.jpg'
bgImageStyle: {
    height: 330px
}
faceImage: '/avatar.png'
---